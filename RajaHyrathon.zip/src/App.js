import "./App.css";
import Navbar from "./Navbar";
import Image1 from "./assets/product-image-1.png";
import Image2 from "./assets/product-image-2.png";
import Image3 from "./assets/product-image-3.png";
import { useState } from "react";

function App() {
  const [quantity, setQuantity] = useState(1);
  return (
    <div>
      <Navbar />
      <div style={{ display: "flex" }}>
        <div>
          <div>
            <img
              style={{ padding: ".4rem", width: "400px", height: "500px" }}
              src={Image1}
              alt="Image1"
            />
            <img
              style={{ padding: ".4rem", width: "400px", height: "500px" }}
              src={Image2}
              alt="Image2"
            />
          </div>
          <div>
            <img
              style={{ padding: ".4rem", width: "400px", height: "500px" }}
              src={Image2}
              alt="Image3"
            />
            <img
              style={{ padding: ".4rem", width: "400px", height: "500px" }}
              src={Image3}
              alt="Image4"
            />
          </div>
        </div>
        <div style={{ marginLeft: "1rem",width:'25%'}}>
          <p>Clothing Company</p>
          <h1>Ruffled Sleeveless Top</h1>
          <span style={{ textDecoration: "line-through" }}>
            Rs. 1,500.00{" "}
          </span>{" "}
          &nbsp;&nbsp; <span>Rs. 899.00</span>
          <p>Size</p>
          <div>
            <button class="size">S</button> &nbsp;&nbsp;
            <button class="size">M</button> &nbsp;&nbsp;
            <button class="size">L</button> &nbsp;&nbsp;
            <button class="size">XL</button> &nbsp;&nbsp;
          </div>
          <p>Quantity</p>
          <p
            style={{
              border: "1px solid",
              padding: "0.3rem",
              display: "inline",
            }}
          >
            <button
              className="quantity"
              onClick={() => setQuantity(quantity - 1)}
            >
              -
            </button>{" "}
            &nbsp;
            <span>{quantity}</span> &nbsp;
            <button
              className="quantity"
              onClick={() => setQuantity(quantity + 1)}
            >
              +
            </button>{" "}
            &nbsp;
          </p>{" "}
          <br /> <br />
          <button className="cart-buynow">Add to Cart</button>
          <button className="cart-buynow">Buy it now</button><br/>
          <span >A dreamy feminine piece, this top is made from a medium weight extra soft cotton blend with light airy feeland paper-like quality</span>
          <br/>
          <br/>
          <span>Designed with voluminous ruffled straps as well as ruffle details accross the chest, it has a straight cut fit and square neck line.</span>
        </div>
      </div>
    </div>
  );
}

export default App;
