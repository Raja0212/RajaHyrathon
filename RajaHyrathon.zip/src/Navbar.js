import React from 'react'
import BlackLogo from './assets/black_logo.png'
// import {Search} from './assets/icon-search.svg'
// import Profile from './assets/icon-profile.svg'
// import Cart from './assets/icon-cart.svg'

function Navbar() {
  return (
    <div style={{display: 'flex',justifyContent: 'space-between',margin: '2rem'}}>
        <img src={BlackLogo} alt='Logo' width="150" height="50"/>
        <div>
            <span style={{padding:'.4rem'}}>Men</span>
            <span style={{padding:'.4rem'}}>Women</span>
            <span style={{padding:'.4rem'}}>Kids</span>
            <span style={{padding:'.4rem'}}>Home & Living</span>
        </div>
        <div>
            <img style={{padding:'.4rem'}} src='/assets/icon-search.svg' alt='Search'/>
            <img style={{padding:'.4rem'}} src='./assets/icon-profile.png' alt='Profile'/>
            <img style={{padding:'.4rem'}} src='./assets/icon-cart.png' alt='Cart'/>
        </div>
    </div>
  )
}

export default Navbar